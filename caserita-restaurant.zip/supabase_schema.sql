-- =========================================================================
-- ESQUEMA DE BASE DE DATOS PARA RESTAURANTE "CASERITA"
-- Ejecuta este script en el Editor SQL de tu proyecto en Supabase (https://database.new)
-- =========================================================================

-- 1. Tabla de Elementos del Menú (menu_items)
CREATE TABLE IF NOT EXISTS menu_items (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price NUMERIC(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL, -- 'starters', 'mains', 'desserts', 'drinks'
    image_url TEXT,
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Tabla de Reservaciones (reservations)
CREATE TABLE IF NOT EXISTS reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    guests_count INTEGER NOT NULL CHECK (guests_count > 0),
    special_requests TEXT,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'confirmed', 'cancelled'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Tabla de Pedidos (orders)
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    delivery_address TEXT, -- Nulo si es retiro
    order_type VARCHAR(20) NOT NULL, -- 'pickup', 'delivery'
    total_price NUMERIC(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'preparing', 'completed', 'cancelled'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Detalles del Pedido (order_items)
CREATE TABLE IF NOT EXISTS order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    menu_item_id INTEGER REFERENCES menu_items(id) ON DELETE SET NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(10, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Tabla de Reseñas de Clientes (reviews)
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name VARCHAR(100) NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar lectura pública (Row Level Security - RLS) si es necesario,
-- o crear políticas básicas para permitir lectura/escritura pública en este proyecto de demostración.
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Políticas para MENU_ITEMS
CREATE POLICY "Permitir lectura pública de menú" ON menu_items 
    FOR SELECT USING (true);
CREATE POLICY "Permitir gestión de menú a admin" ON menu_items 
    FOR ALL USING (true); -- En producción esto se restringiría por rol

-- Políticas para RESERVATIONS
CREATE POLICY "Permitir insertar reservaciones" ON reservations 
    FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir ver reservaciones propias/todas" ON reservations 
    FOR SELECT USING (true);
CREATE POLICY "Permitir actualizar reservaciones" ON reservations 
    FOR UPDATE USING (true);

-- Políticas para ORDERS y ORDER_ITEMS
CREATE POLICY "Permitir insertar pedidos" ON orders 
    FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir ver pedidos" ON orders 
    FOR SELECT USING (true);
CREATE POLICY "Permitir actualizar pedidos" ON orders 
    FOR UPDATE USING (true);

CREATE POLICY "Permitir insertar items de pedido" ON order_items 
    FOR INSERT WITH CHECK (true);
CREATE POLICY "Permitir ver items de pedido" ON order_items 
    FOR SELECT USING (true);

-- Políticas para REVIEWS
CREATE POLICY "Permitir ver reseñas públicas" ON reviews 
    FOR SELECT USING (true);
CREATE POLICY "Permitir insertar reseñas" ON reviews 
    FOR INSERT WITH CHECK (true);

-- =========================================================================
-- DATOS SEMILLA PARA EL MENÚ (menu_items)
-- =========================================================================
INSERT INTO menu_items (name, description, price, category, image_url, available) VALUES
-- Entradas (starters)
('Empanaditas Caseras (3 uds)', 'Empanadas tradicionales de carne picada a cuchillo o queso, al horno de barro.', 6.50, 'starters', '/images/empanada.jpg', true),
('Provoleta Especial', 'Queso provolone fundido con orégano, tomates cherry confitados y aceite de oliva virgen extra.', 7.90, 'starters', '/images/provoleta.jpg', true),
('Bruschettas Criollas', 'Pan de campo tostado frotado con ajo, cubierto de tomates frescos, albahaca y una pizca de ají molido.', 5.80, 'starters', '/images/bruschetta.jpg', true),

-- Platos Fuertes (mains)
('Asado de la Casa con Papas', 'Corte de carne premium asado a fuego lento, servido con papas rústicas al romero.', 18.90, 'mains', '/images/asado.jpg', true),
('Milanesa de la Abuela Napolitana', 'Pechuga de pollo o carne vacuna empanada, cubierta con salsa de tomate de la casa, jamón cocido y abundante queso muzzarella fundido.', 14.50, 'mains', '/images/milanesa.jpg', true),
('Pastel de Papas Tradicional', 'Capas de puré de papa cremoso y carne vacuna guisada con cebollas, aceitunas y huevo duro, gratinado al horno.', 12.00, 'mains', '/images/pastel.jpg', true),
('Sorrentinos Caseros de Calabaza', 'Pasta artesanal rellena de calabaza asada y queso brie, con salsa de crema y salvia.', 13.50, 'mains', '/images/sorrentinos.jpg', true),

-- Postres (desserts)
('Flan Casero con Dulce de Leche', 'El clásico flan con huevos de campo, servido con copo de dulce de leche artesanal y crema montada.', 5.50, 'desserts', '/images/flan.jpg', true),
('Torta Balcarce', 'Torta de bizcochuelo con dulce de leche, crema, merengues triturados y castañas en almíbar.', 6.20, 'desserts', '/images/torta.jpg', true),
('Panqueque con Dulce de Leche', 'Panqueque tibio relleno de dulce de leche, caramelizado al hierro.', 5.00, 'desserts', '/images/panqueque.jpg', true),

-- Bebidas (drinks)
('Limonada Casera con Menta y Jengibre', 'Jarra de limonada fresca exprimida en el momento con menta y un toque de jengibre.', 4.50, 'drinks', '/images/lemonade.jpg', true),
('Vino Malbec Caserita (Copa)', 'Selección especial de la casa, ideal para acompañar carnes rojas y pastas.', 5.00, 'drinks', '/images/wine.jpg', true),
('Cerveza Artesanal Golden (Pinta)', 'Cerveza rubia local de cuerpo ligero y notas cítricas.', 4.80, 'drinks', '/images/beer.jpg', true);
