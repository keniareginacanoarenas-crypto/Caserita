import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Star, AlertCircle, MessageSquare } from 'lucide-react';

const LOCAL_FALLBACK_REVIEWS = [
  { id: '1', customer_name: 'Carlos Mendoza', rating: 5, comment: 'La comida es realmente exquisita. Las empanadas criollas y el asado de la casa tienen ese verdadero sabor a leña y hogar. ¡100% recomendado!', created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '2', customer_name: 'Patricia Silva', rating: 5, comment: 'El flan casero con dulce de leche es de otro planeta. El servicio es sumamente amable y la ambientación es muy acogedora. Volveré sin duda.', created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString() },
  { id: '3', customer_name: 'Roberto Gómez', rating: 4, comment: 'Muy buena comida tradicional. La milanesa napolitana estaba perfecta y crujiente. Excelente relación precio-calidad.', created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString() }
];

export default function Reviews() {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFallback, setIsFallback] = useState(false);
  
  // Estado del formulario
  const [formData, setFormData] = useState({ name: '', comment: '' });
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      setReviews(data || []);
      setIsFallback(false);
    } catch (err) {
      console.warn('Usando opiniones de demostración local:', err.message);
      setReviews(LOCAL_FALLBACK_REVIEWS);
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);
    setSubmitSuccess(false);

    try {
      const reviewPayload = {
        customer_name: formData.name,
        rating: rating,
        comment: formData.comment
      };

      const { data, error: sbError } = await supabase
        .from('reviews')
        .insert([reviewPayload])
        .select();

      if (sbError) {
        throw sbError;
      }

      // Si se guardó en Supabase exitosamente, volvemos a cargar
      setSubmitSuccess(true);
      setFormData({ name: '', comment: '' });
      setRating(5);
      fetchReviews();
    } catch (err) {
      console.warn('Fallo guardando reseña en Supabase, agregando localmente:', err.message);
      
      // Simular guardado localmente añadiéndola al estado
      const mockReview = {
        id: 'MOCK-' + Math.random().toString(),
        customer_name: formData.name,
        rating: rating,
        comment: formData.comment,
        created_at: new Date().toISOString()
      };
      
      setReviews((prev) => [mockReview, ...prev]);
      setSubmitSuccess(true);
      setFormData({ name: '', comment: '' });
      setRating(5);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="reviews-section section container fade-in">
      <h2 className="section-title">La Opinión de Nuestros Clientes</h2>
      <p className="section-subtitle">
        Tu experiencia nos inspira a cocinar con el corazón. Descubre lo que dicen sobre Caserita.
      </p>

      {isFallback && (
        <div className="alert alert-warning">
          <AlertCircle size={20} />
          <div>
            <strong>Modo Demostración Activo:</strong> Las reseñas se leen y agregan localmente. Conecta Supabase para almacenarlas en la base de datos persistente.
          </div>
        </div>
      )}

      <div className="reviews-layout">
        {/* Formulario para Dejar Reseña */}
        <div className="reviews-form-container card">
          <h3>Escribe tu Reseña</h3>
          
          {submitSuccess ? (
            <div className="review-success-msg fade-in">
              <span className="success-emoji">🎉</span>
              <h4>¡Gracias por tu opinión!</h4>
              <p>Tu comentario ha sido publicado exitosamente.</p>
              <button className="btn btn-outline" onClick={() => setSubmitSuccess(false)}>
                Escribir otra reseña
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="review-form">
              {submitError && (
                <div className="alert alert-error">
                  <AlertCircle size={18} />
                  <div>{submitError}</div>
                </div>
              )}

              <div className="form-group">
                <label htmlFor="rev-name">Tu Nombre</label>
                <input
                  type="text"
                  id="rev-name"
                  name="name"
                  className="form-control"
                  required
                  placeholder="Ej. Pedro Pérez"
                  value={formData.name}
                  onChange={handleInputChange}
                />
              </div>

              <div className="form-group">
                <label>Calificación</label>
                <div className="star-rating-selector">
                  {[1, 2, 3, 4, 5].map((starValue) => (
                    <button
                      key={starValue}
                      type="button"
                      className="star-btn"
                      onClick={() => setRating(starValue)}
                      onMouseEnter={() => setHoverRating(starValue)}
                      onMouseLeave={() => setHoverRating(0)}
                    >
                      <Star
                        size={28}
                        className={
                          (hoverRating || rating) >= starValue 
                            ? 'star-filled' 
                            : 'star-empty'
                        }
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="rev-comment">Comentario</label>
                <textarea
                  id="rev-comment"
                  name="comment"
                  className="form-control"
                  required
                  placeholder="Cuéntanos qué te pareció la comida y la atención..."
                  value={formData.comment}
                  onChange={handleInputChange}
                />
              </div>

              <button type="submit" className="btn btn-primary review-submit-btn" disabled={submitting}>
                {submitting ? 'Publicando...' : 'Publicar Reseña'}
              </button>
            </form>
          )}
        </div>

        {/* Listado de Reseñas */}
        <div className="reviews-list-container">
          <h3>Opiniones Recientes ({reviews.length})</h3>
          
          {loading ? (
            <div className="loading-spinner">Cargando comentarios...</div>
          ) : reviews.length === 0 ? (
            <div className="no-items">
              <MessageSquare size={48} className="empty-reviews-icon" />
              <p>Aún no hay opiniones. ¡Sé el primero en compartir tu experiencia!</p>
            </div>
          ) : (
            <div className="reviews-list">
              {reviews.map((rev) => (
                <div key={rev.id} className="review-card card fade-in">
                  <div className="review-card-header">
                    <h4 className="review-author">{rev.customer_name}</h4>
                    <span className="review-date">
                      {new Date(rev.created_at).toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                  <div className="review-rating">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        size={16}
                        className={rev.rating >= star ? 'star-filled' : 'star-empty'}
                      />
                    ))}
                  </div>
                  <p className="review-comment">"{rev.comment}"</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
