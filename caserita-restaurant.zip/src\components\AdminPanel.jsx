import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Shield, Clock, Calendar, Check, X, RefreshCw, ShoppingBag, AlertCircle } from 'lucide-react';

const MOCK_ORDERS = [
  { id: 'ORD-101', customer_name: 'Juan Pérez', customer_phone: '+56 9 1111 2222', customer_email: 'juan@perez.com', order_type: 'delivery', delivery_address: 'Calle Falsa 123', total_price: 25.40, status: 'pending', created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString() },
  { id: 'ORD-102', customer_name: 'Ana María', customer_phone: '+56 9 3333 4444', customer_email: 'ana@maria.com', order_type: 'pickup', delivery_address: '', total_price: 11.00, status: 'preparing', created_at: new Date(Date.now() - 60 * 60 * 1000).toISOString() }
];

const MOCK_RESERVATIONS = [
  { id: 'RES-201', customer_name: 'Sofía Larraín', customer_phone: '+56 9 5555 6666', customer_email: 'sofia@larrain.com', reservation_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0], reservation_time: '20:30', guests_count: 4, special_requests: 'Mesa exterior por favor.', status: 'pending', created_at: new Date().toISOString() },
  { id: 'RES-202', customer_name: 'Diego Muñoz', customer_phone: '+56 9 7777 8888', customer_email: 'diego@munoz.com', reservation_date: new Date().toISOString().split('T')[0], reservation_time: '13:00', guests_count: 2, special_requests: 'Celebración de aniversario.', status: 'confirmed', created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() }
];

export default function AdminPanel() {
  const [orders, setOrders] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFallback, setIsFallback] = useState(false);
  const [activeTab, setActiveTab] = useState('orders');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // 1. Cargar Pedidos de Supabase
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      // 2. Cargar Reservaciones de Supabase
      const { data: reservationsData, error: reservationsError } = await supabase
        .from('reservations')
        .select('*')
        .order('reservation_date', { ascending: true })
        .order('reservation_time', { ascending: true });

      if (ordersError || reservationsError) {
        throw new Error('No se pudo establecer conexión con Supabase');
      }

      setOrders(ordersData || []);
      setReservations(reservationsData || []);
      setIsFallback(false);
    } catch (err) {
      console.warn('Usando base de datos simulada en Panel de Administración:', err.message);
      setOrders(MOCK_ORDERS);
      setReservations(MOCK_RESERVATIONS);
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    try {
      if (isFallback || orderId.startsWith('ORD-')) {
        // Simular localmente
        setOrders((prev) =>
          prev.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order))
        );
        return;
      }

      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;
      fetchData();
    } catch (err) {
      alert('Error al actualizar estado del pedido: ' + err.message);
    }
  };

  const handleUpdateReservationStatus = async (resId, newStatus) => {
    try {
      if (isFallback || resId.startsWith('RES-')) {
        // Simular localmente
        setReservations((prev) =>
          prev.map((res) => (res.id === resId ? { ...res, status: newStatus } : res))
        );
        return;
      }

      const { error } = await supabase
        .from('reservations')
        .update({ status: newStatus })
        .eq('id', resId);

      if (error) throw error;
      fetchData();
    } catch (err) {
      alert('Error al actualizar estado de la reserva: ' + err.message);
    }
  };

  return (
    <section className="admin-section section container fade-in">
      <div className="admin-header">
        <div className="admin-title-group">
          <Shield size={32} className="admin-logo-icon" />
          <h2 className="section-title" style={{ textAlign: 'left', margin: 0 }}>Panel de Control</h2>
        </div>
        <button className="btn btn-outline" onClick={fetchData} disabled={loading}>
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} /> Actualizar Datos
        </button>
      </div>

      <p className="section-subtitle" style={{ textAlign: 'left', marginLeft: 0 }}>
        Visualiza y gestiona las solicitudes de tus clientes en tiempo real. 
      </p>

      {isFallback && (
        <div className="alert alert-warning">
          <AlertCircle size={20} />
          <div>
            <strong>Modo Demostración:</strong> Estás interactuando con datos en memoria del navegador. 
            Las modificaciones no se guardarán permanentemente hasta que configures las credenciales de Supabase en tu <code>.env</code>.
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="admin-tabs">
        <button
          className={`admin-tab-btn ${activeTab === 'orders' ? 'active' : ''}`}
          onClick={() => setActiveTab('orders')}
        >
          <ShoppingBag size={18} /> Pedidos Recibidos ({orders.length})
        </button>
        <button
          className={`admin-tab-btn ${activeTab === 'reservations' ? 'active' : ''}`}
          onClick={() => setActiveTab('reservations')}
        >
          <Calendar size={18} /> Reservas de Mesa ({reservations.length})
        </button>
      </div>

      {loading ? (
        <div className="loading-spinner">Cargando base de datos...</div>
      ) : activeTab === 'orders' ? (
        /* VISTA DE PEDIDOS */
        <div className="admin-content-grid">
          {orders.length === 0 ? (
            <div className="no-items">No se han recibido pedidos todavía.</div>
          ) : (
            orders.map((order) => (
              <div key={order.id} className="admin-data-card card fade-in">
                <div className="card-header-admin">
                  <div>
                    <span className={`badge ${
                      order.status === 'pending' ? 'badge-warning' : 
                      order.status === 'preparing' ? 'badge-primary' : 
                      order.status === 'completed' ? 'badge-success' : 'badge-danger'
                    }`}>
                      {order.status === 'pending' ? 'Pendiente' : 
                       order.status === 'preparing' ? 'Preparando' : 
                       order.status === 'completed' ? 'Completado' : 'Cancelado'}
                    </span>
                    <h4 className="admin-card-id">{order.id}</h4>
                  </div>
                  <span className="admin-card-time">
                    {new Date(order.created_at).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="admin-card-body">
                  <p><strong>Cliente:</strong> {order.customer_name}</p>
                  <p><strong>Teléfono:</strong> {order.customer_phone}</p>
                  <p><strong>Correo:</strong> {order.customer_email}</p>
                  <p><strong>Tipo:</strong> {order.order_type === 'delivery' ? '🚗 Envío a Domicilio' : '🏃 Retiro en Local'}</p>
                  {order.delivery_address && <p><strong>Dirección:</strong> {order.delivery_address}</p>}
                  <p className="admin-card-total">Total: <span>${parseFloat(order.total_price).toFixed(2)}</span></p>
                </div>

                <div className="admin-card-actions">
                  {order.status === 'pending' && (
                    <button 
                      className="btn-admin-act btn-admin-prep" 
                      onClick={() => handleUpdateOrderStatus(order.id, 'preparing')}
                      title="Marcar como Preparando"
                    >
                      <Clock size={16} /> Preparar
                    </button>
                  )}
                  {order.status === 'preparing' && (
                    <button 
                      className="btn-admin-act btn-admin-comp" 
                      onClick={() => handleUpdateOrderStatus(order.id, 'completed')}
                      title="Marcar como Completado"
                    >
                      <Check size={16} /> Completar
                    </button>
                  )}
                  {order.status !== 'completed' && order.status !== 'cancelled' && (
                    <button 
                      className="btn-admin-act btn-admin-canc" 
                      onClick={() => handleUpdateOrderStatus(order.id, 'cancelled')}
                      title="Cancelar Pedido"
                    >
                      <X size={16} /> Cancelar
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        /* VISTA DE RESERVAS */
        <div className="admin-content-grid">
          {reservations.length === 0 ? (
            <div className="no-items">No hay reservaciones registradas.</div>
          ) : (
            reservations.map((res) => (
              <div key={res.id} className="admin-data-card card fade-in">
                <div className="card-header-admin">
                  <div>
                    <span className={`badge ${
                      res.status === 'pending' ? 'badge-warning' : 
                      res.status === 'confirmed' ? 'badge-success' : 'badge-danger'
                    }`}>
                      {res.status === 'pending' ? 'Por Confirmar' : 
                       res.status === 'confirmed' ? 'Confirmada' : 'Cancelada'}
                    </span>
                    <h4 className="admin-card-id">{res.customer_name}</h4>
                  </div>
                  <span className="admin-card-time">
                    {res.guests_count} {res.guests_count === 1 ? 'Persona' : 'Personas'}
                  </span>
                </div>

                <div className="admin-card-body">
                  <p><strong>Fecha:</strong> {res.reservation_date}</p>
                  <p><strong>Hora:</strong> {res.reservation_time}</p>
                  <p><strong>Teléfono:</strong> {res.customer_phone}</p>
                  <p><strong>Correo:</strong> {res.customer_email}</p>
                  {res.special_requests && (
                    <p className="admin-card-note">
                      <strong>Notas:</strong> "{res.special_requests}"
                    </p>
                  )}
                </div>

                <div className="admin-card-actions">
                  {res.status === 'pending' && (
                    <button 
                      className="btn-admin-act btn-admin-comp" 
                      onClick={() => handleUpdateReservationStatus(res.id, 'confirmed')}
                      title="Confirmar Reserva"
                    >
                      <Check size={16} /> Confirmar
                    </button>
                  )}
                  {res.status !== 'cancelled' && (
                    <button 
                      className="btn-admin-act btn-admin-canc" 
                      onClick={() => handleUpdateReservationStatus(res.id, 'cancelled')}
                      title="Cancelar Reserva"
                    >
                      <X size={16} /> Cancelar
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </section>
  );
}
