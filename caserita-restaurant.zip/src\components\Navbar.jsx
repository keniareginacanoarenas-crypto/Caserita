import React, { useState } from 'react';
import { ShoppingBasket, Menu, X, Utensils, Calendar, Star, ShieldCheck } from 'lucide-react';

export default function Navbar({ activeSection, setActiveSection, cartCount, toggleCart }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Inicio', icon: Utensils },
    { id: 'menu', label: 'Nuestro Menú', icon: Utensils },
    { id: 'reservations', label: 'Reservaciones', icon: Calendar },
    { id: 'reviews', label: 'Opiniones', icon: Star },
    { id: 'admin', label: 'Administración', icon: ShieldCheck },
  ];

  const handleNavClick = (sectionId) => {
    setActiveSection(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="navbar glass">
      <div className="navbar-container">
        {/* Logo */}
        <div className="navbar-logo" onClick={() => handleNavClick('home')}>
          <span className="logo-icon">🍳</span>
          <span className="logo-text">Caserita <span className="logo-sub">Restaurant</span></span>
        </div>

        {/* Desktop Navigation */}
        <ul className="nav-links">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  className={`nav-link-btn ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => handleNavClick(item.id)}
                >
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Actions (Cart & Mobile Toggle) */}
        <div className="nav-actions">
          <button className="cart-trigger-btn" onClick={toggleCart} aria-label="Ver carrito">
            <ShoppingBasket size={24} />
            {cartCount > 0 && <span className="cart-badge-count pulse">{cartCount}</span>}
          </button>

          <button
            className="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="mobile-nav-menu fade-in">
          <ul className="mobile-nav-links">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  className={`mobile-nav-link-btn ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => handleNavClick(item.id)}
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </nav>
  );
}
