import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || supabaseUrl.includes('reemplaza-con-tu-url') || !supabaseAnonKey || supabaseAnonKey.includes('reemplaza-con-tu-anon-key')) {
  console.warn(
    '⚠️ Supabase no está configurado. Por favor, edita el archivo .env en la raíz del proyecto con tus credenciales de Supabase.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
