import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Menu from './components/Menu';
import Cart from './components/Cart';
import Reservations from './components/Reservations';
import Reviews from './components/Reviews';
import AdminPanel from './components/AdminPanel';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Funciones del Carrito
  const addToCart = (item) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((cartItem) => cartItem.id === item.id);
      if (existingItem) {
        return prevCart.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem
        );
      }
      return [...prevCart, { ...item, quantity: 1 }];
    });
    // Abrir carrito automáticamente al agregar un plato para mejorar la experiencia de usuario
    setIsCartOpen(true);
  };

  const updateQuantity = (itemId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) => (item.id === itemId ? { ...item, quantity } : item))
    );
  };

  const removeFromCart = (itemId) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Renderizado condicional de secciones
  const renderSection = () => {
    switch (activeSection) {
      case 'home':
        return (
          <>
            <Hero setActiveSection={setActiveSection} />
            
            {/* Sección destacada de presentación en el Inicio */}
            <section className="about-preview section container fade-in" style={{ padding: '60px 0' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px', alignItems: 'center' }}>
                <div>
                  <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '2.4rem', marginBottom: '16px', color: 'var(--color-secondary)' }}>Nuestra Filosofía</h2>
                  <p style={{ color: 'var(--color-text-light)', marginBottom: '20px', fontSize: '1.05rem' }}>
                    Creemos que la comida conecta a las personas. Por eso, en <strong>Caserita</strong> no hay atajos: amasamos nuestro propio pan, molemos nuestras propias especias y seleccionamos las verduras del mercado cada mañana.
                  </p>
                  <button className="btn btn-outline" onClick={() => setActiveSection('menu')}>
                    Ver la Carta Completa
                  </button>
                </div>
                <div className="card" style={{ padding: '30px', backgroundColor: 'var(--color-secondary)', color: 'white' }}>
                  <h3 style={{ fontFamily: 'var(--font-serif)', color: 'white', marginBottom: '16px', fontSize: '1.6rem' }}>Recomendado del Día</h3>
                  <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '16px' }}>
                    <span style={{ fontSize: '2.5rem' }}>🥩</span>
                    <div>
                      <h4 style={{ color: 'white', fontSize: '1.1rem' }}>Asado de la Casa con Papas</h4>
                      <p style={{ color: '#BFC9CA', fontSize: '0.9rem' }}>Corte premium asado lentamente al horno de barro.</p>
                    </div>
                  </div>
                  <button 
                    className="btn btn-primary" 
                    style={{ width: '100%', border: 'none' }}
                    onClick={() => setActiveSection('menu')}
                  >
                    Ordenar Ahora
                  </button>
                </div>
              </div>
            </section>
          </>
        );
      case 'menu':
        return <Menu addToCart={addToCart} />;
      case 'reservations':
        return <Reservations />;
      case 'reviews':
        return <Reviews />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <Hero setActiveSection={setActiveSection} />;
    }
  };

  return (
    <div className="app-layout">
      {/* Navegación */}
      <Navbar
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        cartCount={cartCount}
        toggleCart={() => setIsCartOpen(!isCartOpen)}
      />

      {/* Sección Principal */}
      <main style={{ minHeight: 'calc(100vh - 380px)' }}>
        {renderSection()}
      </main>

      {/* Carrito Flotante (Slide-over Drawer) */}
      <Cart
        cart={cart}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
        clearCart={clearCart}
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
      />

      {/* Pie de Página */}
      <footer className="footer">
        <div className="footer-grid container">
          <div className="footer-brand">
            <h3>🍳 Caserita</h3>
            <p>Sabor tradicional con amor de hogar. La mejor comida casera preparada con los ingredientes más frescos.</p>
          </div>
          <div className="footer-col">
            <h4>Navegación</h4>
            <ul>
              <li><button onClick={() => setActiveSection('home')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer' }}>Inicio</button></li>
              <li><button onClick={() => setActiveSection('menu')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer' }}>Menú</button></li>
              <li><button onClick={() => setActiveSection('reservations')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer' }}>Reservaciones</button></li>
              <li><button onClick={() => setActiveSection('reviews')} style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer' }}>Opiniones</button></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Contacto</h4>
            <p>📍 Av. Principal 123, Ciudad</p>
            <p>📞 +56 9 1234 5678</p>
            <p>✉️ contacto@caserita.com</p>
          </div>
          <div className="footer-col">
            <h4>Horarios</h4>
            <p>Martes a Domingo</p>
            <p>12:00 PM - 11:00 PM</p>
            <p>Lunes Cerrado</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} Caserita Restaurant. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;

