import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Search, ShoppingBasket, AlertCircle } from 'lucide-react';

const LOCAL_FALLBACK_MENU = [
  { id: 1, name: 'Empanaditas Caseras (3 uds)', description: 'Empanadas tradicionales de carne picada a cuchillo o queso, al horno de barro.', price: 6.50, category: 'starters', image_url: '/images/empanada.jpg' },
  { id: 2, name: 'Provoleta Especial', description: 'Queso provolone fundido con orégano, tomates cherry confitados y aceite de oliva virgen extra.', price: 7.90, category: 'starters', image_url: '/images/provoleta.jpg' },
  { id: 3, name: 'Bruschettas Criollas', description: 'Pan de campo tostado frotado con ajo, cubierto de tomates frescos, albahaca y una pizca de ají molido.', price: 5.80, category: 'starters', image_url: '/images/bruschetta.jpg' },
  { id: 4, name: 'Asado de la Casa con Papas', description: 'Corte de carne premium asado a fuego lento, servido con papas rústicas al romero.', price: 18.90, category: 'mains', image_url: '/images/asado.jpg' },
  { id: 5, name: 'Milanesa de la Abuela Napolitana', description: 'Pechuga de pollo o carne vacuna empanada, cubierta con salsa de tomate de la casa, jamón cocido y abundante queso muzzarella fundido.', price: 14.50, category: 'mains', image_url: '/images/milanesa.jpg' },
  { id: 6, name: 'Pastel de Papas Tradicional', description: 'Capas de puré de papa cremoso y carne vacuna guisada con cebollas, aceitunas y huevo duro, gratinado al horno.', price: 12.00, category: 'mains', image_url: '/images/pastel.jpg' },
  { id: 7, name: 'Sorrentinos Caseros de Calabaza', description: 'Pasta artesanal rellena de calabaza asada y queso brie, con salsa de crema y salvia.', price: 13.50, category: 'mains', image_url: '/images/sorrentinos.jpg' },
  { id: 8, name: 'Flan Casero con Dulce de Leche', description: 'El clásico flan con huevos de campo, servido con copo de dulce de leche artesanal y crema montada.', price: 5.50, category: 'desserts', image_url: '/images/flan.jpg' },
  { id: 9, name: 'Torta Balcarce', description: 'Torta de bizcochuelo con dulce de leche, crema, merengues triturados y castañas en almíbar.', price: 6.20, category: 'desserts', image_url: '/images/torta.jpg' },
  { id: 10, name: 'Panqueque con Dulce de Leche', description: 'Panqueque tibio relleno de dulce de leche, caramelizado al hierro.', price: 5.00, category: 'desserts', image_url: '/images/panqueque.jpg' },
  { id: 11, name: 'Limonada Casera con Menta y Jengibre', description: 'Jarra de limonada fresca exprimida en el momento con menta y un toque de jengibre.', price: 4.50, category: 'drinks', image_url: '/images/lemonade.jpg' },
  { id: 12, name: 'Vino Malbec Caserita (Copa)', description: 'Vino tinto joven aromático de la selección especial de la casa.', price: 5.00, category: 'drinks', image_url: '/images/wine.jpg' },
  { id: 13, name: 'Cerveza Artesanal Golden (Pinta)', description: 'Cerveza rubia local de cuerpo ligero y notas cítricas.', price: 4.80, category: 'drinks', image_url: '/images/beer.jpg' }
];

const FALLBACK_IMAGE_URL = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=60';

export default function Menu({ addToCart }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFallback, setIsFallback] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', label: 'Todos' },
    { id: 'starters', label: 'Entradas' },
    { id: 'mains', label: 'Platos Fuertes' },
    { id: 'desserts', label: 'Postres' },
    { id: 'drinks', label: 'Bebidas' }
  ];

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('menu_items')
        .select('*')
        .order('id', { ascending: true });

      if (error || !data || data.length === 0) {
        throw new Error('Supabase no conectado o menú vacío');
      }

      setItems(data);
      setIsFallback(false);
    } catch (err) {
      console.warn('Usando menú de demostración local:', err.message);
      setItems(LOCAL_FALLBACK_MENU);
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = items.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="menu-section section container fade-in">
      <h2 className="section-title">Nuestra Carta</h2>
      <p className="section-subtitle">
        Elige entre nuestra selección de delicias caseras cocinadas al momento.
      </p>

      {isFallback && (
        <div className="alert alert-warning">
          <AlertCircle size={20} />
          <div>
            <strong>Modo Demostración Activo:</strong> Cargando platos desde almacenamiento local. 
            Para conectar con tu base de datos real, ejecuta el archivo <code>supabase_schema.sql</code> en Supabase y actualiza tu <code>.env</code>.
          </div>
        </div>
      )}

      {/* Filtros e Historial */}
      <div className="menu-controls">
        <div className="category-filters">
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`filter-btn ${activeCategory === cat.id ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat.id)}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="search-bar-wrapper">
          <Search className="search-icon" size={20} />
          <input
            type="text"
            className="search-input"
            placeholder="Buscar plato..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="loading-spinner">Cargando platos sabrosos...</div>
      ) : filteredItems.length === 0 ? (
        <div className="no-items">No encontramos platos que coincidan con tu búsqueda.</div>
      ) : (
        <div className="menu-grid">
          {filteredItems.map((item) => (
            <div key={item.id} className="menu-card card">
              <div className="menu-card-image-wrapper">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="menu-card-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = FALLBACK_IMAGE_URL;
                  }}
                />
                <span className="menu-card-category">{categories.find(c => c.id === item.category)?.label}</span>
              </div>
              <div className="menu-card-body">
                <div className="menu-card-header">
                  <h3 className="menu-card-title">{item.name}</h3>
                  <span className="menu-card-price">${parseFloat(item.price).toFixed(2)}</span>
                </div>
                <p className="menu-card-description">{item.description}</p>
                <button 
                  className="btn btn-primary menu-card-btn"
                  onClick={() => addToCart(item)}
                >
                  <ShoppingBasket size={18} /> Agregar al Carrito
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
