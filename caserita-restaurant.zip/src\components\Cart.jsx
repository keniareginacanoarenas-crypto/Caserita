import React, { useState } from 'react';
import { supabase } from '../supabaseClient';
import { X, Trash2, ShoppingBag, Plus, Minus, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Cart({ cart, updateQuantity, removeFromCart, clearCart, isOpen, onClose }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    type: 'pickup',
    address: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [createdOrderId, setCreatedOrderId] = useState(null);

  if (!isOpen) return null;

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (cart.length === 0) return;

    try {
      setSubmitting(true);
      setError(null);

      // 1. Validaciones básicas
      if (formData.type === 'delivery' && !formData.address.trim()) {
        throw new Error('Por favor, ingresa una dirección de entrega.');
      }

      // 2. Intentar guardar en Supabase
      let savedOrder = null;

      // Creamos el objeto del pedido
      const orderPayload = {
        customer_name: formData.name,
        customer_email: formData.email,
        customer_phone: formData.phone,
        order_type: formData.type,
        delivery_address: formData.type === 'delivery' ? formData.address : null,
        total_price: total,
        status: 'pending'
      };

      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert([orderPayload])
        .select();

      if (orderError) {
        console.warn('Fallo guardando pedido en Supabase, simulando éxito localmente:', orderError.message);
      } else if (orderData && orderData.length > 0) {
        savedOrder = orderData[0];
      }

      // 3. Intentar guardar los platos asociados
      if (savedOrder) {
        const orderItemsPayload = cart.map((item) => ({
          order_id: savedOrder.id,
          menu_item_id: Number.isInteger(item.id) && item.id <= 13 ? null : item.id, // Si usa IDs mock que no existen en DB, los guardamos como null o el id real si es uuid
          quantity: item.quantity,
          unit_price: item.price
        }));

        const { error: itemsError } = await supabase
          .from('order_items')
          .insert(orderItemsPayload);

        if (itemsError) {
          console.error('Error insertando platos del pedido:', itemsError);
        }
      }

      // 4. Éxito
      setCreatedOrderId(savedOrder ? savedOrder.id : 'MOCK-' + Math.floor(Math.random() * 100000));
      setSuccess(true);
      clearCart();
      setFormData({ name: '', email: '', phone: '', type: 'pickup', address: '' });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="cart-overlay fade-in" onClick={onClose}>
      <div className="cart-drawer" onClick={(e) => e.stopPropagation()}>
        {/* Encabezado */}
        <div className="cart-header">
          <div className="cart-header-title">
            <ShoppingBag size={22} className="cart-header-icon" />
            <h2>Tu Pedido</h2>
          </div>
          <button className="cart-close-btn" onClick={onClose} aria-label="Cerrar carrito">
            <X size={24} />
          </button>
        </div>

        {success ? (
          /* Mensaje de Éxito */
          <div className="cart-success-state fade-in">
            <CheckCircle2 size={64} className="success-icon-large animate-pulse" />
            <h3>¡Muchas gracias por tu compra!</h3>
            <p>Hemos recibido tu pedido en <strong>Caserita</strong>.</p>
            <div className="success-details">
              <p><strong>Código de Pedido:</strong></p>
              <code className="order-code">{createdOrderId}</code>
              <p>Nos comunicaremos al teléfono ingresado para confirmar los detalles.</p>
            </div>
            <button className="btn btn-primary" onClick={() => { setSuccess(false); onClose(); }}>
              Seguir Explorando
            </button>
          </div>
        ) : (
          /* Contenido del Carrito */
          <div className="cart-content-wrapper">
            {cart.length === 0 ? (
              <div className="cart-empty-state fade-in">
                <ShoppingBag size={64} className="empty-cart-icon" />
                <p>Tu carrito está vacío.</p>
                <button className="btn btn-primary" onClick={onClose}>
                  Ver el Menú
                </button>
              </div>
            ) : (
              <>
                {/* Listado de Platos */}
                <div className="cart-items-list">
                  {cart.map((item) => (
                    <div key={item.id} className="cart-item">
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="cart-item-image"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100&auto=format&fit=crop&q=60';
                        }}
                      />
                      <div className="cart-item-details">
                        <h4 className="cart-item-name">{item.name}</h4>
                        <span className="cart-item-price">${parseFloat(item.price).toFixed(2)}</span>
                        <div className="cart-item-controls">
                          <button 
                            className="quantity-btn" 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus size={14} />
                          </button>
                          <span className="cart-item-quantity">{item.quantity}</span>
                          <button 
                            className="quantity-btn" 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                      <button 
                        className="cart-item-delete-btn" 
                        onClick={() => removeFromCart(item.id)}
                        aria-label="Eliminar plato"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Subtotal */}
                <div className="cart-totals">
                  <div className="cart-total-row">
                    <span>Subtotal</span>
                    <strong>${total.toFixed(2)}</strong>
                  </div>
                </div>

                {/* Formulario de Pedido */}
                <form className="cart-checkout-form" onSubmit={handleSubmit}>
                  <h3>Datos del Cliente</h3>
                  
                  {error && (
                    <div className="alert alert-error">
                      <AlertCircle size={18} />
                      <div>{error}</div>
                    </div>
                  )}

                  <div className="form-group">
                    <label htmlFor="name">Nombre Completo</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      className="form-control"
                      required
                      placeholder="Ej. Juan Pérez"
                      value={formData.name}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="email">Correo Electrónico</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      className="form-control"
                      required
                      placeholder="juan@correo.com"
                      value={formData.email}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="phone">Teléfono de Contacto</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      className="form-control"
                      required
                      placeholder="Ej. +56 9 1234 5678"
                      value={formData.phone}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="form-group">
                    <label>Tipo de Entrega</label>
                    <div className="delivery-type-selectors">
                      <label className={`delivery-selector-card ${formData.type === 'pickup' ? 'active' : ''}`}>
                        <input
                          type="radio"
                          name="type"
                          value="pickup"
                          checked={formData.type === 'pickup'}
                          onChange={handleInputChange}
                          className="hidden-radio"
                        />
                        <span>🏃 Retiro en Local</span>
                      </label>
                      <label className={`delivery-selector-card ${formData.type === 'delivery' ? 'active' : ''}`}>
                        <input
                          type="radio"
                          name="type"
                          value="delivery"
                          checked={formData.type === 'delivery'}
                          onChange={handleInputChange}
                          className="hidden-radio"
                        />
                        <span>🚗 Despacho a Domicilio</span>
                      </label>
                    </div>
                  </div>

                  {formData.type === 'delivery' && (
                    <div className="form-group fade-in">
                      <label htmlFor="address">Dirección de Entrega</label>
                      <textarea
                        id="address"
                        name="address"
                        className="form-control"
                        required
                        placeholder="Calle, número, depto u oficina"
                        value={formData.address}
                        onChange={handleInputChange}
                      />
                    </div>
                  )}

                  <button 
                    type="submit" 
                    className="btn btn-primary checkout-submit-btn" 
                    disabled={submitting}
                  >
                    {submitting ? 'Procesando Pedido...' : `Enviar Pedido ($${total.toFixed(2)})`}
                  </button>
                </form>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
