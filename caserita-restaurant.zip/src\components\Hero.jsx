import React from 'react';
import { ChevronRight, Calendar, BookOpen } from 'lucide-react';

export default function Hero({ setActiveSection }) {
  return (
    <header className="hero-section">
      <div className="hero-overlay"></div>
      <div className="hero-container container">
        <div className="hero-content fade-in">
          <div className="hero-tag">Comida Tradicional & Casera</div>
          <h1 className="hero-title">
            El verdadero sabor de la comida <span className="highlight">hecha en casa</span>
          </h1>
          <p className="hero-description">
            En <strong>Caserita</strong>, rescatamos las recetas tradicionales de la abuela. Utilizando ingredientes locales frescos, preparamos cada plato con paciencia, dedicación y ese toque único de amor hogareño que te hará sentir como en casa.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-primary" onClick={() => setActiveSection('menu')}>
              <BookOpen size={18} /> Explora Nuestro Menú
            </button>
            <button className="btn btn-secondary hero-btn-sec" onClick={() => setActiveSection('reservations')}>
              <Calendar size={18} /> Reserva una Mesa
            </button>
          </div>
          <div className="hero-info-pills">
            <div className="info-pill">
              <span className="pill-icon">📍</span>
              <div>
                <h4>Visítanos</h4>
                <p>Av. Principal 123, Ciudad</p>
              </div>
            </div>
            <div className="info-pill">
              <span className="pill-icon">🕒</span>
              <div>
                <h4>Horarios</h4>
                <p>Mar - Dom: 12:00 - 23:00</p>
              </div>
            </div>
            <div className="info-pill">
              <span className="pill-icon">📞</span>
              <div>
                <h4>Llámanos</h4>
                <p>+56 9 1234 5678</p>
              </div>
            </div>
          </div>
        </div>
        <div className="hero-image-container fade-in">
          <div className="hero-image-wrapper">
            <img 
              src="/images/hero.jpg" 
              alt="Platos tradicionales y deliciosos de Caserita" 
              className="hero-image" 
              onError={(e) => {
                e.target.onerror = null; 
                e.target.src = 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=60';
              }}
            />
            <div className="hero-badge">
              <span className="badge-star">★</span>
              <span className="badge-text">Sabor 100% Auténtico</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
